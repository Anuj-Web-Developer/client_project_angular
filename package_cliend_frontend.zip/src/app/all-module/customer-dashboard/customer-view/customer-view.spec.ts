import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerView } from './customer-view';

describe('CustomerView', () => {
  let component: CustomerView;
  let fixture: ComponentFixture<CustomerView>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CustomerView]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomerView);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
